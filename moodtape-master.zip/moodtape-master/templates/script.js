function showDiv() {
   document.getElementById('load').style.display = "block";
}